/*
*
* IBM Confidential
* OCO Source Materials
* 5724X98 5724Y15 5655V82 5724X99 5724Y16 5655V89 5725B69 5655W88 5725C52 5655W90 5655Y31
* Copyright IBM Corp. 1987, 2014
* The source code for this program is not published or other-
* wise divested of its trade secrets, irrespective of what has
* been deposited with the U.S Copyright Office.
*
*/

package loan;



/**
 * Result
 */
public enum LoanRefusalCause {
	NONE,
	INVALID_DATA,
	HIGH_DEBT_INCOME_RATIO,
	LOW_CREDIT_SCORE,
	LOW_GRADE,
	OTHER
};
